<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Graella;

class GraellaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $graellas = Graella::all()->toArray();
        return view('graella.index', compact('graellas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('graella.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'nom_canal'    =>  'required',
            'nom_programa'    =>  'required',
            'hora'    =>  'required',
            'dia'    =>  'required'
        ]);
        $graella = new Graella([
            'nom_canal'    =>  $request->get('nom_canal'),
            'nom_programa'    =>  $request->get('nom_programa'),
            'hora'    =>  $request->get('hora'),
            'dia'    =>  $request->get('dia')
        ]);
        $graella->save();
        return redirect()->route('graella.index')->with('success', 'Data Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $graella = Graella::find($id);
        return view('graella.edit', compact('graella', 'id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'nom_canal'    =>  'required',
            'nom_programa'    =>  'required',
            'hora'    =>  'required',
            'dia'    =>  'required'
        ]);
        $graella = Graella::find($id);
        $graella->nom_canal = $request->get('nom_canal');
        $graella->nom_programa = $request->get('nom_programa');
        $graella->hora = $request->get('hora');
        $graella->dia = $request->get('dia');
        $graella->save();
        return redirect()->route('graella.index')->with('success', 'Data Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $graella = Graella::find($id);
        $graella->delete();
        return redirect()->route('graella.index')->with('success', 'Data Deleted');
    }
}