<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Graella extends Model
{
    protected $fillable = ['nom_canal', 'nom_programa', 'hora', 'dia'];
}