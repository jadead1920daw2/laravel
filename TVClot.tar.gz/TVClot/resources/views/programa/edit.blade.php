@extends('master')

@section('content')

<div align="left">
   <br />
   <a href="/programa" class="btn btn-primary">Torna enrere</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Edita programa</h3>
  <br />
  @if(count($errors) > 0)

  <div class="alert alert-danger">
         <ul>
         @foreach($errors->all() as $error)
          <li>{{$error}}</li>
         @endforeach
         </ul>
  @endif
  <form method="post" action="{{action('ProgramaController@update', $id)}}">
   {{csrf_field()}}
   <input type="hidden" name="_method" value="PATCH" />
   <div class="form-group">
    <input type="text" name="nom_programa" class="form-control" value="{{$programa->nom_programa}}" placeholder="Introdueix el nom del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="descripcio" class="form-control" value="{{$programa->descripcio}}" placeholder="Introdueix la descripcio del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="tipus" class="form-control" value="{{$programa->tipus}}" placeholder="Introdueix el tipus de programa" />
   </div>
   <div class="form-group">
    <input type="text" name="classificacio" class="form-control" value="{{$programa->classificacio}}" placeholder="Introdueix la classificacio del programa" />
   </div>
   <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Edit" />
   </div>
  </form>
 </div>
</div>

@endsection