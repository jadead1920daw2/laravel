@extends('master')

@section('content')

<div align="left">
   <br />
   <a href="/canal" class="btn btn-primary">Torna enrere</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Edita canal</h3>
  <br />
  @if(count($errors) > 0)

  <div class="alert alert-danger">
         <ul>
         @foreach($errors->all() as $error)
          <li>{{$error}}</li>
         @endforeach
         </ul>
  @endif
  <form method="post" action="{{action('CanalController@update', $id)}}">
   {{csrf_field()}}
   <input type="hidden" name="_method" value="PATCH" />
   <div class="form-group">
    <input type="text" name="nom_canal" class="form-control" value="{{$canal->nom_canal}}" placeholder="Introdueix el nom del canal" />
   </div>
   <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Edit" />
   </div>
  </form>
 </div>
</div>

@endsection