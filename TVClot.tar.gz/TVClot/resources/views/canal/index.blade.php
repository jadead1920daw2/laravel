@extends('master')

@section('content')

<div align="left">
   <br />
   <a href="/" class="btn btn-primary">Inici</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Gestió de canals</h3>
  <br />
  @if($message = Session::get('success'))
  <div class="alert alert-success">
   <p>{{$message}}</p>
  </div>
  @endif
  <div align="right">
   <a href="{{route('canal.create')}}" class="btn btn-primary">Afegeix</a>
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Canal</th>
    <th>Edita</th>
    <th>Esborra</th>
   </tr>
   @foreach($canals as $row)
   <tr>
    <td>{{$row['nom_canal']}}</td>
    <td><a href="{{action('CanalController@edit', $row['id'])}}" class="btn btn-warning">Edita</a></td>
    <td>
     <form method="post" class="delete_form" action="{{action('CanalController@destroy', $row['id'])}}">
      {{csrf_field()}}
      <input type="hidden" name="_method" value="DELETE" />
      <button type="submit" class="btn btn-danger">Esborra</button>
     </form>
    </td>
   </tr>
   @endforeach
  </table>
 </div>
</div>
<script>
$(document).ready(function(){
 $('.delete_form').on('submit', function(){
  if(confirm("Estàs segur de que ho vols esborrar?"))
  {
   return true;
  }
  else
  {
   return false;
  }
 });
});
</script>
@endsection