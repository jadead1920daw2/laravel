@extends('master')

@section('content')

<div align="left">
   <br />
   <a href="/graella" class="btn btn-primary">Torna enrere</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Edita la graella d'emissió</h3>
  <br />
  @if(count($errors) > 0)

  <div class="alert alert-danger">
         <ul>
         @foreach($errors->all() as $error)
          <li>{{$error}}</li>
         @endforeach
         </ul>
  @endif
  <form method="post" action="{{action('GraellaController@update', $id)}}">
   {{csrf_field()}}
   <input type="hidden" name="_method" value="PATCH" />
   <div class="form-group">
    <input type="text" name="nom_canal" class="form-control" value="{{$graella->nom_canal}}" placeholder="Introdueix el nom del canal" />
   </div>
   <div class="form-group">
    <input type="text" name="nom_programa" class="form-control" value="{{$graella->nom_programa}}" placeholder="Introdueix el nom del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="hora" class="form-control" value="{{$graella->hora}}" placeholder="Introdueix l'hora d'emissio del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="dia" class="form-control" value="{{$graella->dia}}" placeholder="Introdueix el dia d'emissio del programa" />
   </div>
   <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Edit" />
   </div>
  </form>
 </div>
</div>

@endsection