<?php $__env->startSection('content'); ?>

<div align="left">
   <br />
   <a href="/programa" class="btn btn-primary">Torna enrere</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Edita programa</h3>
  <br />
  <?php if(count($errors) > 0): ?>

  <div class="alert alert-danger">
         <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
  <?php endif; ?>
  <form method="post" action="<?php echo e(action('ProgramaController@update', $id)); ?>">
   <?php echo e(csrf_field()); ?>

   <input type="hidden" name="_method" value="PATCH" />
   <div class="form-group">
    <input type="text" name="nom_programa" class="form-control" value="<?php echo e($programa->nom_programa); ?>" placeholder="Introdueix el nom del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="descripcio" class="form-control" value="<?php echo e($programa->descripcio); ?>" placeholder="Introdueix la descripcio del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="tipus" class="form-control" value="<?php echo e($programa->tipus); ?>" placeholder="Introdueix el tipus de programa" />
   </div>
   <div class="form-group">
    <input type="text" name="classificacio" class="form-control" value="<?php echo e($programa->classificacio); ?>" placeholder="Introdueix la classificacio del programa" />
   </div>
   <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Edit" />
   </div>
  </form>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/TVClot/resources/views/programa/edit.blade.php ENDPATH**/ ?>