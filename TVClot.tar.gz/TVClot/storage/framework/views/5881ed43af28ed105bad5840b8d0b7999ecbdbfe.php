<?php $__env->startSection('content'); ?>

<div align="left">
   <br />
   <a href="/graella" class="btn btn-primary">Torna enrere</a>
   <br />
</div>

<div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Edita la graella d'emissió</h3>
  <br />
  <?php if(count($errors) > 0): ?>

  <div class="alert alert-danger">
         <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
  <?php endif; ?>
  <form method="post" action="<?php echo e(action('GraellaController@update', $id)); ?>">
   <?php echo e(csrf_field()); ?>

   <input type="hidden" name="_method" value="PATCH" />
   <div class="form-group">
    <input type="text" name="nom_canal" class="form-control" value="<?php echo e($graella->nom_canal); ?>" placeholder="Introdueix el nom del canal" />
   </div>
   <div class="form-group">
    <input type="text" name="nom_programa" class="form-control" value="<?php echo e($graella->nom_programa); ?>" placeholder="Introdueix el nom del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="hora" class="form-control" value="<?php echo e($graella->hora); ?>" placeholder="Introdueix l'hora d'emissio del programa" />
   </div>
   <div class="form-group">
    <input type="text" name="dia" class="form-control" value="<?php echo e($graella->dia); ?>" placeholder="Introdueix el dia d'emissio del programa" />
   </div>
   <div class="form-group">
    <input type="submit" class="btn btn-primary" value="Edit" />
   </div>
  </form>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/TVClot/resources/views/graella/edit.blade.php ENDPATH**/ ?>